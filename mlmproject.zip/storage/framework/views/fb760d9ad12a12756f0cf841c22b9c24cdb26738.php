<?php $__env->startSection('content'); ?>
    <div class="main">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-8 p-r-0 title-margin-right">
                    <div class="page-header">
                        <div class="page-title">
                            <h1>Hello, <span>Welcome to <?php echo e(env('APP_NAME')); ?></span></h1>

                        </div>
                    </div>
                </div>
                <!-- /# column -->
                <div class="col-lg-4 p-l-0 title-margin-left">
                    <div class="page-header">
                        <div class="page-title">
                            <ol class="breadcrumb text-right">
                                <li><a href="#">Dashboard</a></li>
                                <li class="active">Home</li>
                            </ol>
                        </div>
                    </div>
                </div>
                <!-- /# column -->
            </div>
            <!-- /# row -->
            <div class="main-content">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card p-10">
                            <b style="color: #555;">Share your referral link with others</b><br>
                            <a href="<?php echo e(route('refferal.link')); ?>" class="btn btn-info">Referral Link</a>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="card p-0">
                                        <div class="stat-widget-three">
                                            <div class="stat-icon bg-primary">
                                                <i class="ti-wallet"></i>
                                            </div>
                                            <div class="stat-content">
                                                <div class="stat-text">Total</div>
                                                <div
                                                    class="stat-digit"><?php echo e($totalAmount - ($totalWithdraw + $withdrawPending + $totalWithdrawFees + $withdrawPendingFees)); ?></div>
                                            </div>

                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="card p-0">
                                        <div class="stat-widget-three">
                                            <div class="stat-icon bg-success">
                                                <i class="ti-bag"></i>
                                            </div>
                                            <div class="stat-content">
                                                <div class="stat-text">Today Member</div>
                                                <div class="stat-digit"><?php echo e($today); ?></div>
                                            </div>

                                        </div>
                                    </div>
                                </div>


                                <div class="col-lg-6">
                                    <div class="card bg-success">
                                        <div class="stat-widget-six">
                                            <div class="stat-icon p-15">
                                                <i class="ti-stats-up"></i>
                                            </div>
                                            <div class="stat-content p-t-12 p-b-12">
                                                <div class="text-left dib">
                                                    <div class="stat-heading">Withdraw</div>
                                                    <div class="stat-text"><?php echo e($totalWithdraw); ?></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="card bg-primary">
                                        <div class="stat-widget-six">
                                            <div class="stat-icon p-15">
                                                <i class="ti-stats-up"></i>
                                            </div>
                                            <div class="stat-content p-t-12 p-b-12">
                                                <div class="text-left dib">
                                                    <div class="stat-heading">Withdraw Pending</div>
                                                    <div class="stat-text"><?php echo e($withdrawPending); ?></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4> Referral List </h4>
                                    <div class="card-header-right-icon">
                                        <ul>
                                            <li class="card-close" data-dismiss="alert"><i class="ti-close"></i></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <table class="table table-bordered table-levels text-left">
                                        <thead>
                                        <tr>
                                            <th>User Id</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Referral ID</th>
                                            <th>Join At</th>

                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $uplines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $upline): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($upline->User): ?>
                                                <tr>
                                                    <td style="background: white !important;"><?php echo e($upline->user_id); ?></td>
                                                    <td><?php echo e($upline->User->name); ?></td>
                                                    <td><?php echo e($upline->User->email); ?></td>
                                                    <td><?php echo e($upline->User->referral_code); ?></td>
                                                    <td style="text-align: left !important;"><?php echo e($upline->User->created_at->diffForHumans()); ?></td>
                                                </tr>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                    <?php echo e($uplines->links()); ?>




                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    

                                    
                                    
                                    



                                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12" style="margin-top: 7px;">
                            <div class="card">
                                <div class="card-header"
                                     style="background: #1DE9B6 !important;border: none;border-radius: 0;">
                                    <h4 style="color: #fff !important;">Loan Indicator</h4>
                                    <div class="card-header-right-icon" style="color: #fff;font-weight: bold;">
                                    </div>
                                </div>
                                <table class="table table-bordered" style="font-size: 14px;">
                                    <thead>
                                    <tr>
                                        <th>Level</th>
                                        <th>Direct Refferal(Retrainer)</th>
                                        <th>Loan Accessible(Ksh)</th>
                                        <th>Grace Period(Days)</th>
                                        <th>Loan Period(Days)</th>
                                        <th>% Direct Purchases</th>
                                        <th>Bonuses(Ksh)</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                        $loanPeriod =[30,30,90,90,180,180,270,270,36,360,null];
                                        $directPurchases =[65,50,50,50,35,35,25,25,20,15,10];
                                       $gracePeriod = [7,7,7,10,10,10,15,15,20,20,0];
                                        $ranger = [20,40,60,80,100,120,140,160,180,200,10000000000000000];

                                    ?>
                                    <?php for($i=1;$i<=11;$i++): ?>
                                        <?php if(auth()->user()->TotalUpline->{'level'.$i} !=0 && auth()->user()->TotalUpline->{'level'.$i} <= $ranger[$i-1]): ?>
                                        <tr>
                                            <td><?php echo e($i); ?></td>
                                            <?php if(auth()->user()->TotalUpline): ?>
                                                <td><?php echo e(auth()->user()->TotalUpline->{'level'.$i}); ?></td>
                                            <?php else: ?>
                                                <td></td>
                                            <?php endif; ?>
                                            <?php if(auth()->user()->LevelIncome): ?>
                                                <td><?php echo e(auth()->user()->LevelIncome->{'level'.$i}); ?></td>
                                            <?php else: ?>
                                                <td></td>
                                            <?php endif; ?>
                                            <td><?php echo e($gracePeriod[$i-1]); ?></td>

                                            <td><?php echo e($loanPeriod[$i-1]); ?></td>
                                            <td><?php echo e($directPurchases[$i-1]); ?></td>
                                            <?php if($i == 2 || $i == 6 || $i == 10): ?>
                                                <?php if($i == 2): ?>
                                                    <td>2000</td>
                                                <?php endif; ?>
                                                <?php if($i == 6): ?>
                                                    <td>6000</td>
                                                <?php endif; ?>
                                                <?php if($i == 10): ?>
                                                    <td>1200</td>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <td>-</td>
                                            <?php endif; ?>
                                        </tr>
                                        <?php endif; ?>
                                    <?php endfor; ?>

                                    </tbody>
                                </table>
                            </div>

                        </div>
                        <!-- /# column -->
                    </div>
                    <!-- /# row -->
                    <div class="row">

                        <!-- /# column -->
                        <div class="col-lg-12">
                            <div class="card alert">
                                <div class="card-header">
                                    <h4> Level and Earnings table </h4>
                                    <div class="card-header-right-icon">
                                        <ul>
                                            <li class="card-close" data-dismiss="alert"><i class="ti-close"></i></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <table class="table table-bordered table-levels">
                                        <thead>
                                        <tr>
                                            <th>Level</th>
                                            <th>Direct Level</th>
                                            <th>Loan Accessible</th>
                                            <th>Achieve Date</th>
                                            <th>Release Date</th>
                                            <th>Payable by date</th>
                                            <th>Bonuses
                                                (Ksh)
                                            </th>

                                        </tr>
                                        </thead>
                                        <tbody>

                                        <?php if(auth()->user()->TotalUpline): ?>
                                            <?php
                                                $withdraw = \App\Withdraw::with('LoanApprove')->where('user_id',auth()->user()->id)->first();
                                                $bonus = \App\MemberBonus::with('User')->where('user_id',auth()->user()->id)->where('level',"level$i")->first();
                                            ?>

                                            <?php for($i=1;$i<=11;$i++): ?>

                                                <tr>
                                                    <td>Level <?php echo e($i); ?></td>
                                                    <?php if(auth()->user()->TotalUpline): ?>
                                                        <td><?php echo e(auth()->user()->TotalUpline->{'level'.$i}); ?></td>
                                                    <?php else: ?>
                                                        <td></td>
                                                    <?php endif; ?>

                                                    <?php if(auth()->user()->LevelIncome): ?>
                                                        <td><?php echo e(auth()->user()->LevelIncome->{'level'.$i}); ?></td>
                                                    <?php else: ?>
                                                        <td></td>
                                                    <?php endif; ?>

                                                    <?php if(auth()->user()->TotalUpline): ?>

                                                        <?php if($withdraw && auth()->user()->TotalUpline->{'level'.$i}): ?>
                                                            <?php if($withdraw->LoanApprove): ?>
                                                                <td><?php echo e(\Carbon\Carbon::parse($withdraw->LoanApprove->release_date)->format('Y-m-d')); ?></td>
                                                            <?php endif; ?>
                                                        <?php else: ?>
                                                            <td>

                                                            </td>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <td></td>
                                                    <?php endif; ?>



                                                    <?php if(auth()->user()->TotalUpline): ?>
                                                        <?php if($withdraw && auth()->user()->TotalUpline->{'level'.$i}): ?>
                                                            <td>
                                                                <?php if($withdraw->LoanApprove): ?>
                                                                    <?php echo e(\Carbon\Carbon::parse($withdraw->LoanApprove->release_date)->format('Y-m-d')); ?>

                                                                <?php endif; ?>
                                                            </td>
                                                        <?php else: ?>
                                                            <td>

                                                            </td>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <td></td>
                                                    <?php endif; ?>
                                                    <?php if(auth()->user()->TotalUpline): ?>
                                                        <?php if($withdraw && auth()->user()->TotalUpline->{'level'.$i}): ?>
                                                            <?php if($withdraw->LoanApprove): ?>
                                                               <td><?php echo e(\Carbon\Carbon::parse($withdraw->LoanApprove->payable_by_date)->format('Y-m-d')); ?></td>
                                                            <?php endif; ?>


                                                        <?php else: ?>
                                                            <td>

                                                            </td>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <td></td>
                                                    <?php endif; ?>

                                                    <?php if(auth()->user()->TotalUpline): ?>
                                                        <?php if($bonus && auth()->user()->TotalUpline->{'level'.$i}): ?>
                                                            <td>
                                                                <?php echo e($bonus->bonus); ?>

                                                            </td>
                                                        <?php else: ?>
                                                            <td>

                                                            </td>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <td></td>
                                                    <?php endif; ?>

                                                </tr>
                                            <?php endfor; ?>
                                        <?php else: ?>
                                            <tr>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                        <?php endif; ?>


                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <!-- /# column -->
                    </div>


                    <!-- /# row -->
                </div>
                <!-- /# main content -->
            </div>
            <!-- /# container-fluid -->
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\phpdir\htdocs\mlmproject\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>