<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo e(env('APP_NAME')); ?> | Register</title>

    <!-- ================= Favicon ================== -->
    <!-- Standard -->
    <link rel="shortcut icon" href="http://placehold.it/64.png/000/fff">
    <!-- Retina iPad Touch Icon-->
    <link rel="apple-touch-icon" sizes="144x144" href="http://placehold.it/144.png/000/fff">
    <!-- Retina iPhone Touch Icon-->
    <link rel="apple-touch-icon" sizes="114x114" href="http://placehold.it/114.png/000/fff">
    <!-- Standard iPad Touch Icon-->
    <link rel="apple-touch-icon" sizes="72x72" href="http://placehold.it/72.png/000/fff">
    <!-- Standard iPhone Touch Icon-->
    <link rel="apple-touch-icon" sizes="57x57" href="http://placehold.it/57.png/000/fff">

    <!-- Styles -->
    <link href="<?php echo e(asset('assets/css/lib/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/lib/themify-icons.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/lib/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/lib/unix.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">
</head>

<body class="bg-primary">

<div class="unix-login">
    <div class="container">

        <div class="row">
            <div class="col-lg-5 col-lg-offset-3">
                <div class="login-content">
                    <?php if(!$refferal_id): ?>
                        <h4 style="color: #fff;background: red;padding: 10px;border-radius: 4px;">
                            <span>Invalid referral link</span>
                            <span>
                            <p>Please add valid Referral id</p>
                        </span>
                        </h4>
                    <?php endif; ?>
                    <div class="login-logo">

                    </div>
                    <div class="login-form">
                        <p style="font-size: 30px;font-family: cursive;text-align: center;color: #0ea432;"><?php echo e(env('APP_NAME')); ?></p>

                        <form method="POST" action="<?php echo e(route('register')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <label>Name</label>
                                <input type="name" name="name" class="form-control" placeholder="Name">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong class="error-form" style="color: red;"><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>
                            <div class="form-group <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <label>Email</label>
                                <input type="email" name="email" class="form-control" placeholder="Email">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong class="error-form" style="color: red;"><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>
                            <div class="form-group <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <label>Password</label>
                                <input id="password" type="password"
                                       class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password"
                                       required autocomplete="new-password">
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong class="error-form" style="color: red;"><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <label>Confirm Password</label>
                                <input id="password-confirm" type="password" class="form-control"
                                       name="password_confirmation" required autocomplete="new-password">
                                <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong class="error-form" style="color: red;"><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <label>Phone Number</label>
                                <input id="phone" type="text" class="form-control"
                                       name="phone" required>
                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong class="error-form" style="color: red;"><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <label>Country</label>
                                <select id="country" class="form-control"
                                        name="country">
                                    <option value="Mombas">
                                        Mombas
                                    </option>
                                    <option value="Kwale"> Kwale</option>
                                    <option value="Kilifi"> Kilifi</option>
                                    <option value="Tana River"> Tana River</option>
                                    <option value="Lamu"> Lamu</option>
                                    <option value="Taita Taveta"> Taita Taveta</option>
                                    <option value="Garissa"> Garissa</option>
                                    <option value="Wajir"> Wajir</option>
                                    <option value="Mandera"> Mandera</option>
                                    <option value="Marsabit"> Marsabit</option>
                                    <option value="Isiolo"> Isiolo</option>
                                    <option value="Meru"> Meru</option>
                                    <option value="Tharaka Nithi"> Tharaka Nithi</option>
                                    <option value="Embu"> Embu</option>
                                    <option value="Kitui"> Kitui</option>
                                    <option value="Machakos"> Machakos</option>
                                    <option value="Makueni"> Makueni</option>
                                    <option value="Nyandarua"> Nyandarua</option>
                                    <option value="Nyeri"> Nyeri</option>
                                    <option value="Kirinyaga"> Kirinyaga</option>
                                    <option value="Murang’a"> Murang’a</option>
                                    <option value="Kiambu"> Kiambu</option>
                                    <option value="Turkana"> Turkana</option>
                                    <option value="West Pokot"> West Pokot</option>
                                    <option value="Samburu"> Samburu</option>
                                    <option value="Uasin Gishu"> Uasin Gishu</option>
                                    <option value="Trans-Nzoia"> Trans-Nzoia</option>
                                    <option value="Elgeyo-Marakwet"> Elgeyo-Marakwet</option>
                                    <option value="Nandi"> Nandi</option>
                                    <option value="Baringo"> Baringo</option>
                                    <option value="Laikipia"> Laikipia</option>
                                    <option value="Nakuru"> Nakuru</option>
                                    <option value="Narok"> Narok</option>
                                    <option value="Kajiado"> Kajiado</option>
                                    <option value="Kericho"> Kericho</option>
                                    <option value="Bomet"> Bomet</option>
                                    <option value="Kakamega"> Kakamega</option>
                                    <option value="Vihiga"> Vihiga</option>
                                    <option value="Bungoma"> Bungoma</option>
                                    <option value="Busia"> Busia</option>
                                    <option value="Siaya"> Siaya</option>
                                    <option value="Kisumu"> Kisumu</option>
                                    <option value="Homa Bay"> Homa Bay</option>
                                    <option value="Migori"> Migori</option>
                                    <option value="Kisii"> Kisii</option>
                                    <option value="Nyamira"> Nyamira</option>
                                    <option value="Nairobi"> Nairobi</option>
                                </select>
                                <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong class="error-form" style="color: red;"><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <?php if($refferal_id): ?>
                                <div class="form-group">
                                    <label>Referral ID</label>
                                    <input type="hidden" class="form-control" name="referral_code"
                                           value="<?php echo e($refferal_id); ?>">
                                    <input type="text" class="form-control" value="<?php echo e($refferal_id); ?>" disabled>

                                </div>
                            <?php endif; ?>

                            <button type="submit" class="btn btn-primary btn-flat m-b-30 m-t-30"
                                    <?php if(!$refferal_id): ?> disabled <?php endif; ?>>  <?php echo e(__('Register')); ?></button>

                            <div class="register-link m-t-15 text-center">
                                <p>Aready have an account ? <a href="<?php echo e(route('login')); ?>"> Login here</a></p>
                            </div>
                        </form>
                        <div class="boxes"
                             style="background: #eee;padding: 10px ; text-align: center;border-radius: 4px;border: 1px solid #d8d8d8;">
                            <h4 style="line-height: 1em;margin: 10px 0px;padding: 0;">Contact with us:</h4>
                            <p style="word-break: 2px !important;">
                                Email : support@inuabizz.com
                            </p>
                            <p>Phone : +254751730030</p>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

</body>

</html>
<?php /**PATH C:\phpdir\htdocs\mlmproject\resources\views/auth/register.blade.php ENDPATH**/ ?>