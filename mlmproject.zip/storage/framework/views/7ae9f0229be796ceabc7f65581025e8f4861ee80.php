<?php $__env->startSection('content'); ?>
    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
                <section id="main-content">
                    <div class="row">
                        <div class="col-lg-12" style="margin-top: 7px;">
                            <div class="card">
                                <div class="card-header"
                                     style="background: #1DE9B6 !important;border: none;border-radius: 0;">
                                    <h4 style="color: #fff !important;">Level and Earnings</h4>
                                    <div class="card-header-right-icon" style="color: #fff;font-weight: bold;">
                                    </div>
                                </div>
                                <table class="table table-bordered table-levels">
                                    <thead>
                                    <tr>
                                        <th>Level</th>
                                        <th>Direct Refferal(Retrainer)</th>
                                        <th>Loan Accessible(Ksh)</th>
                                        <th>Grace Period(Days)</th>
                                        <th>Loan Period(Days)</th>
                                        <th>% Direct Purchases</th>
                                        <th>Bonuses(Ksh)</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                        $loanPeriod =[30,30,90,90,180,180,270,270,36,360,null];
                                        $directPurchases =[65,50,50,50,35,35,25,25,20,15,10];
                                       $gracePeriod = [7,7,7,10,10,10,15,15,20,20,0];
                                    ?>
                                    <?php for($i=1;$i<=11;$i++): ?>
                                        <tr>
                                            <td><?php echo e($i); ?></td>
                                            <?php if(auth()->user()->TotalUpline): ?>
                                                <td><?php echo e(auth()->user()->TotalUpline->{'level'.$i}); ?></td>
                                            <?php else: ?>
                                                <td></td>
                                            <?php endif; ?>
                                            <?php if(auth()->user()->LevelIncome): ?>
                                                <td><?php echo e(auth()->user()->LevelIncome->{'level'.$i}); ?></td>
                                            <?php else: ?>
                                                <td></td>
                                            <?php endif; ?>
                                            <td><?php echo e($gracePeriod[$i-1]); ?></td>

                                            <td><?php echo e($loanPeriod[$i-1]); ?></td>
                                            <td><?php echo e($directPurchases[$i-1]); ?></td>
                                            <?php if($i == 2 || $i == 6 || $i == 10): ?>
                                                <?php if($i == 2): ?>
                                                    <td>2000</td>
                                                <?php endif; ?>
                                                <?php if($i == 6): ?>
                                                    <td>6000</td>
                                                <?php endif; ?>
                                                <?php if($i == 10): ?>
                                                    <td>1200</td>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <td>-</td>
                                            <?php endif; ?>
                                        </tr>
                                    <?php endfor; ?>

                                    </tbody>
                                </table>
                            </div>

                        </div>
                        <!-- /# column -->
                    </div>
                </section>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\phpdir\htdocs\mlmproject\resources\views/admin/levels-and-earnings.blade.php ENDPATH**/ ?>