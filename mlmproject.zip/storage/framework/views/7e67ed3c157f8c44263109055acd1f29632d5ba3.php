<?php $__env->startSection('content'); ?>
    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
                <section id="main-content">
                    <div class="row">
                        <div class="col-lg-12" style="margin-top: 7px;">
                            <div class="card alert">
                                <div class="card-header"
                                     style="background: #1DE9B6 !important;border: none;border-radius: 0;">
                                    <h4 style="color: #fff !important;">Level Settings</h4>
                                    <div class="card-header-right-icon" style="color: #fff;font-weight: bold;">
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="horizontal-form-elements">
                                        <form class="form-horizontal" method="POST"
                                              action="<?php echo e(route('admin.store-level-settings')); ?>"
                                              enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <?php if(isset($levelSettings->id)): ?>
                                                <input type="hidden" name="id" value="<?php echo e($levelSettings->id); ?>">
                                            <?php endif; ?>

                                            <div class="row">

                                                <div class="col-lg-10">


                                                    <div class="form-group">
                                                        <label
                                                            class="col-sm-2 control-label">Join Income</label>
                                                        <div class="col-sm-10">
                                                            <input type="number" class="form-control input-sm" value="<?php echo e($levelSettings->join_income); ?>"
                                                                   name="join_income">
                                                        </div>
                                                        <?php $__errorArgs = ['join_income'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                           <strong><?php echo e($message); ?></strong>
                                                         </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                    <div class="form-group">
                                                        <label
                                                            class="col-sm-2 control-label">Refferal</label>
                                                        <div class="col-sm-10">
                                                            <input type="number" class="form-control input-sm" value="<?php echo e($levelSettings->refferal); ?>"
                                                                   name="refferal">
                                                        </div>
                                                        <?php $__errorArgs = ['refferal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                           <strong><?php echo e($message); ?></strong>
                                                         </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>

                                                    <div class="form-group">
                                                        <label
                                                            class="col-sm-2 control-label">Minimum Withdraw</label>
                                                        <div class="col-sm-10">
                                                            <input type="number" class="form-control input-sm" value="<?php echo e($levelSettings->minimum_withdraw); ?>"
                                                                   name="minimum_withdraw">
                                                        </div>
                                                        <?php $__errorArgs = ['minimum_withdraw'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                           <strong><?php echo e($message); ?></strong>
                                                         </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>

                                                    <div class="form-group">
                                                        <label
                                                            class="col-sm-2 control-label">Withdraw Fee(%)</label>
                                                        <div class="col-sm-10">
                                                            <input type="number" class="form-control input-sm"
                                                                   name="withdraw_fee" value="<?php echo e($levelSettings->withdraw_fee); ?>">
                                                        </div>
                                                        <?php $__errorArgs = ['withdraw_fee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                           <strong><?php echo e($message); ?></strong>
                                                         </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                    <button type="submit" class="btn btn-success"
                                                            style="margin-left: 120px;">Update
                                                    </button>

                                                </div>
                                                <!-- /# column -->
                                                <!-- /# column -->
                                            </div>
                                        </form>
                                    </div>
                                </div>

                            </div>
                            <!-- /# card -->
                        </div>
                        <!-- /# column -->
                    </div>
                </section>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.superadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\phpdir\htdocs\mlmproject\resources\views/superadmin/level-settings.blade.php ENDPATH**/ ?>