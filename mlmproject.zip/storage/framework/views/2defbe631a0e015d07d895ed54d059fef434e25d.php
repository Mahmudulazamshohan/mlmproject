<?php $__env->startSection('content'); ?>
    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
                <section id="main-content">
                    <div class="row">
                        <div class="col-lg-12" style="margin-top: 7px;">
                            <div class="card alert">
                                <div class="card-header"
                                     style="background: #1DE9B6 !important;border: none;border-radius: 0;">
                                    <h4 style="color: #fff !important;">Users Information</h4>
                                    <div class="card-header-right-icon" style="color: #fff;font-weight: bold;">
                                    </div>
                                </div>
                                <div class="card-body">
                                    <table class="table table-bordered">
                                        <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Earn(Ksh)</th>


                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($user->id); ?></td>
                                            <td><?php echo e($user->name); ?></td>
                                            <td><?php echo e($user->email); ?></td>
                                            <?php if($user->LevelIncome): ?>
                                            <td>
                                                <?php echo e($user->LevelIncome->level1 + $user->LevelIncome->level2 + $user->LevelIncome->level3 +$user->LevelIncome->level4 +$user->LevelIncome->level5 +$user->LevelIncome->level6 +$user->LevelIncome->level7 +$user->LevelIncome->level8 +$user->LevelIncome->level9 +$user->LevelIncome->level10 +$user->LevelIncome->level11); ?>

                                            </td>
                                            <?php else: ?>
                                                <td>
                                                    0
                                                </td>
                                            <?php endif; ?>




                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tbody>
                                    </table>
                                    <?php echo e($users->links()); ?>


                                </div>

                            </div>
                            <!-- /# card -->
                        </div>
                        <!-- /# column -->
                    </div>
                </section>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.superadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\phpdir\htdocs\mlmproject\resources\views/superadmin/users.blade.php ENDPATH**/ ?>