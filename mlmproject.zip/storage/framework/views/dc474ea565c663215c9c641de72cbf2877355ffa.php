<?php $__env->startSection('content'); ?>
    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
                <section id="main-content">
                    <div class="row">
                        <div class="col-lg-12" style="margin-top: 7px;">
                            <div class="card alert">
                                <div class="card-header"
                                     style="background: #1DE9B6 !important;border: none;border-radius: 0;">
                                    <h4 style="color: #fff !important;">Withdraw</h4>
                                    <div class="card-header-right-icon" style="color: #fff;font-weight: bold;">
                                    </div>
                                </div>
                                <div class="card-body">
                                    <p style="margin-left: 30px;" class="text-left text-primary">Current Account Available :- <?php echo e($totalAmount - ($totalWithdraw + $withdrawPending + $totalWithdrawFees + $withdrawPendingFees)); ?> Ksh </p>
                                    <div class="horizontal-form-elements">
                                        <form class="form-horizontal" method="POST"
                                              action="<?php echo e(route('store.withdraw')); ?>"
                                              enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>

                                            <div class="row">

                                                <div class="col-lg-10">


                                                    <div class="form-group">
                                                        <label
                                                            class="col-sm-2 control-label">
                                                            Payout Method
                                                        </label>
                                                        <div class="col-sm-10">
                                                            <input type="radio" name="payment_method" value=mpesa"
                                                                   checked>
                                                            <img
                                                                src="<?php echo e(asset('assets/images/mpesa.png')); ?>" alt=""
                                                                style="width:70px;height: 70px;">
                                                            <input type="radio" name="payment_method"
                                                                   value="bank_transfer"> <img
                                                                src="<?php echo e(asset('assets/images/bank_transfer.png')); ?>"
                                                                alt="" style="width:70px;height: 70px;">

                                                        </div>
                                                        <?php $__errorArgs = ['payment_method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                           <strong><?php echo e($message); ?></strong>
                                                         </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>

                                                    <div class="form-group">
                                                        <label
                                                            class="col-sm-2 control-label">Account /Phone Number</label>
                                                        <div class="col-sm-10">
                                                            <input type="text" class="form-control input-sm" value=""
                                                                   name="account" placeholder="Account Email Address"
                                                                   required>
                                                        </div>
                                                        <?php $__errorArgs = ['account'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                           <strong><?php echo e($message); ?></strong>
                                                         </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>

                                                    <div class="form-group">
                                                        <label
                                                            class="col-sm-2 control-label">Amount</label>
                                                        <div class="col-sm-10">
                                                            <input type="number" class="form-control input-sm" value=""
                                                                   name="amount" placeholder="Amount minimum Ksh 3000"
                                                                   min="3000" required>
                                                        </div>
                                                        <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                           <strong><?php echo e($message); ?></strong>
                                                         </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>


                                                    <button type="submit" class="btn btn-success"
                                                            style="margin-left: 120px;">Submit
                                                    </button>

                                                </div>
                                                <!-- /# column -->
                                                <!-- /# column -->
                                            </div>
                                        </form>
                                    </div>
                                </div>

                            </div>
                            <!-- /# card -->
                        </div>
                        <div class="col-lg-12" style="margin-top: 7px;">
                            <div class="card alert">
                                <div class="card-header"
                                     style="background: #1DE9B6 !important;border: none;border-radius: 0;">
                                    <h4 style="color: #fff !important;">Previous Withdraw</h4>
                                    <div class="card-header-right-icon" style="color: #fff;font-weight: bold;">
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="horizontal-form-elements">
                                        <table class="table table-bordered text-center">
                                            <thead>
                                            <tr>
                                                <th>Account</th>
                                                <th>Payment Method</th>
                                                <th>Amount</th>
                                                <th>Fee</th>
                                                <th>Status</th>
                                            </tr>
                                            </thead>
                                            <tbody>


                                            <?php $__currentLoopData = $withdraws; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $withdraw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($withdraw->account); ?></td>
                                                    <td><?php echo e(strtoupper(str_replace("_"," ",$withdraw->payment_method))); ?></td>
                                                    <td><?php echo e($withdraw->amount); ?></td>
                                                    <td><?php echo e($withdraw->fees); ?></td>
                                                    <td>
                                                        <?php if($withdraw->status): ?>
                                                            <span class="label label-success">Paid</span>
                                                        <?php else: ?>
                                                            <span class="label label-info">Pending</span>
                                                        <?php endif; ?>

                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                        <?php echo e($withdraws->links()); ?>

                                    </div>
                                </div>

                            </div>
                            <!-- /# card -->
                        </div>
                        <!-- /# column -->
                    </div>
                </section>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\phpdir\htdocs\mlmproject\resources\views/admin/withdraw.blade.php ENDPATH**/ ?>