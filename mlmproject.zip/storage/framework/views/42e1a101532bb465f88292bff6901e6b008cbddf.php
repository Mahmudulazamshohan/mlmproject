<?php
    $notifications  =[];
    $total = 0;

    $pushNotifications = \App\PushNotification::all();
    $pushNotificationViews = \App\PushNotificationView::with('PushNotification')->where('id',\Illuminate\Support\Facades\Auth::id())->get();
    foreach ($pushNotificationViews as $pushNotificationView) {
        if($pushNotificationView->PushNotification){
            $total += 1;
        }
    }
    $total = $pushNotifications->count() - $total;
?>
<li class="header-icon dib"><i class="ti-bell"></i>
    <?php if($total): ?>
    <button class="badge badge-success"
            style="width: 25px;height: 25px;border-radius: 50%;border:none;background: #555;color: white;">1
    </button>
    <?php endif; ?>
    <div class="drop-down">
        <div class="dropdown-content-heading">
            <span class="text-left">Recent Notifications</span>
        </div>
        <div class="dropdown-content-body">
            <ul>
                <?php $__currentLoopData = $pushNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pushNotification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="<?php echo e(route('view-notification',$pushNotification->id)); ?>">
                           <div class="notification-content">
                                <small class="notification-timestamp pull-right"><?php echo e($pushNotification->created_at->calendar()); ?></small>
                                <div class="notification-heading">Admin</div>
                                <?php if($pushNotification->text): ?>
                                    <div class="notification-text"><?=$pushNotification->text?></div>
                                <?php endif; ?>
                            </div>
                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                <li class="text-center">
                    <a href="<?php echo e(route('notifications')); ?>" class="more-link" style="width: 100%;height: 100%;">See All</a>
                </li>
            </ul>
        </div>
    </div>
</li>
<?php /**PATH C:\phpdir\htdocs\mlmproject\resources\views/layouts/push-notification.blade.php ENDPATH**/ ?>