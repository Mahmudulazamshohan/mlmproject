<?php $__env->startSection('content'); ?>
    <style>
        [contenteditable]:hover,
        [contenteditable]:focus {
            background: #fff;
        }
    </style>
    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
                <section id="main-content">
                    <div class="row">
                        <div class="col-lg-12" style="margin-top: 7px;">
                            <div class="card">
                                <div class="card-header"
                                     style="background: #1DE9B6 !important;border: none;border-radius: 0;">
                                    <h4 style="color: #fff !important;">
                                        Name: <?php echo e($user->name); ?>

                                    </h4>
                                    <br>
                                    <h4 style="color: #fff !important;">
                                        Email: <?php echo e($user->email); ?>

                                    </h4>
                                    <br>
                                    <h4 style="color: #fff !important;">
                                        Total Loan: <?php echo e($user->Withdraw->sum('amount')); ?>

                                    </h4>
                                    <div class="card-header-right-icon" style="color: #fff;font-weight: bold;">
                                    </div>
                                </div>

                                <table class="table table-bordered">
                                    <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>
                                            Account
                                        </th>
                                      
                                        <th>
                                            Loan (Ksh)
                                        </th>
                                        <th>
                                            Fee(Ksh) (7%)
                                        </th>
                                        <th>
                                            Status
                                        </th>

                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $withdraws; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $withdraw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($withdraw->User->name); ?></td>
                                            <td><?php echo e($withdraw->User->email); ?></td>
                                            <td><?php echo e($withdraw->account); ?></td>

                                            <td><?php echo e($withdraw->amount); ?></td>
                                            <td><?php echo e($withdraw->fees); ?></td>
                                            <?php if(!$withdraw->status): ?>
                                                <td>

                                                    Pending

                                                </td>
                                            <?php else: ?>
                                                <td>
                                                    Approved
                                                </td>
                                            <?php endif; ?>

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </tbody>
                                </table>
                                <?php echo e($withdraws->links()); ?>

                            </div>

                        </div>

                        <!-- /# column -->
                    </div>
                </section>
            </div>
        </div>
    </div>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/nicEdit-latest.js')); ?>"></script>

    <script type="text/javascript">
        new nicEditor().panelInstance('text-editor');
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.superadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\phpdir\htdocs\mlmproject\resources\views/superadmin/member-loan-more.blade.php ENDPATH**/ ?>