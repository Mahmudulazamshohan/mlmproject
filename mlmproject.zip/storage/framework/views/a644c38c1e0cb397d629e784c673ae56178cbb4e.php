<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>
        InuaBiz
    </title>
    <!-- ================= Favicon ================== -->
    <!-- Standard -->
    <link rel="shortcut icon" href="http://placehold.it/64.png/000/fff">
    <!-- Retina iPad Touch Icon-->
    <link rel="apple-touch-icon" sizes="144x144" href="http://placehold.it/144.png/000/fff">
    <!-- Retina iPhone Touch Icon-->
    <link rel="apple-touch-icon" sizes="114x114" href="http://placehold.it/114.png/000/fff">
    <!-- Standard iPad Touch Icon-->
    <link rel="apple-touch-icon" sizes="72x72" href="http://placehold.it/72.png/000/fff">
    <!-- Standard iPhone Touch Icon-->
    <link rel="apple-touch-icon" sizes="57x57" href="http://placehold.it/57.png/000/fff">
    <!-- Styles -->
    <link href="<?php echo e(asset('assets/css/lib/chartist/chartist.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/lib/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/lib/themify-icons.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/lib/owl.carousel.min.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('assets/css/lib/owl.theme.default.min.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('assets/css/lib/weather-icons.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('assets/css/lib/menubar/sidebar.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/lib/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/lib/unix.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/main.css')); ?>" rel="stylesheet">
    <link href="//cdn.rawgit.com/Eonasdan/bootstrap-datetimepicker/e8bddc60e73c1ec2475f827be36e1957af72e2ea/build/css/bootstrap-datetimepicker.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/slim-select/1.23.0/slimselect.min.css" rel="stylesheet"></link>
</head>

<body>
<?php echo $__env->make('partials.admin-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="header">
    <div class="pull-left">
        <div class="logo"><a href="<?php echo e(route('dashboard')); ?>"><span><?php echo e(env('APP_NAME')); ?></span></a></div>
        <div class="hamburger sidebar-toggle">
            <span class="line"></span>
            <span class="line"></span>
            <span class="line"></span>
        </div>
    </div>
    <div class="pull-right p-r-15">
        <ul>


            <li class="header-icon dib">
                <img class="avatar-img" src="<?php echo e(asset('/default-image.jpeg')); ?>" alt="" />
                <span class="user-avatar"><?php if(auth()->guard()->check()): ?> <?php echo e(\Illuminate\Support\Facades\Auth::user()->name); ?><?php endif; ?> <i class="ti-angle-down f-s-10"></i></span>
                <div class="drop-down dropdown-profile">

                    <div class="dropdown-content-body">
                        <ul>
                            <li><a href="<?php echo e(route('admin.profile')); ?>"><i class="ti-user"></i> <span>Profile</span></a></li>

                            <li><a href="#" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();"><i
                                        class="ti-power-off"></i> <span>Logout</span></a></li>
                            <form id="logout-form" action="<?php echo e(route('admin.logout')); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                        </ul>
                    </div>
                </div>
            </li>
        </ul>
    </div>
</div>
<div class="content-wrap">
    <?php echo $__env->yieldContent('content'); ?>

</div>




<div id="search">
    <button type="button" class="close">×</button>
    <form>
        <input type="search" value="" placeholder="type keyword(s) here" />
        <button type="submit" class="btn btn-primary">Search</button>
    </form>

</div>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
<?php
    use Illuminate\Support\Facades\Session;
?>
<script>
    <?php if(Session::has('success')): ?>
    Swal.fire({
        title: 'Saved',
        text: '<?php echo e(Session::get("message")); ?>',
        icon: 'success',
        confirmButtonText: 'Close',
        onClose:function () {
            window.location.reload()
        }
    })
    <?php elseif(Session::has('fail')): ?>
    Swal.fire({
        title: 'Saved',
        text: '<?php echo e(Session::get("message")); ?>',
        icon: 'error',
        confirmButtonText: 'Close',
        onClose:function () {
            window.location.reload()
        }
    })
    <?php endif; ?>
</script>
<!-- jquery vendor -->
<script src="<?php echo e(asset('assets/js/lib/jquery.min.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/slim-select/1.23.0/slimselect.min.js"></script>

<script>
    var APP_URL = '<?php echo e(env('APP_URL')); ?>'
</script>
<script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>

<script src="<?php echo e(asset('assets/js/lib/jquery.nanoscroller.min.js')); ?>"></script>
<!-- nano scroller -->
<script src="<?php echo e(asset('assets/js/lib/menubar/sidebar.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/lib/preloader/pace.min.js')); ?>"></script>
<!-- sidebar -->
<script src="<?php echo e(asset('assets/js/lib/bootstrap.min.js')); ?>"></script>



<!--  Chart js -->
<script src="<?php echo e(asset('assets/js/lib/chart-js/Chart.bundle.js')); ?>"></script>



<!--  Datamap -->
<script src="<?php echo e(asset('assets/js/lib/datamap/d3.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/lib/datamap/topojson.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/lib/datamap/datamaps.world.min.js')); ?>"></script>


<script src="<?php echo e(asset('assets/js/lib/weather/jquery.simpleWeather.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/lib/weather/weather-init.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/lib/owl-carousel/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/lib/owl-carousel/owl.carousel-init.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/lib/data-table/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/lib/data-table/buttons.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/lib/data-table/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/lib/data-table/buttons.flash.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/lib/data-table/jszip.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/lib/data-table/pdfmake.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/lib/data-table/vfs_fonts.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/lib/data-table/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/lib/data-table/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/lib/data-table/datatables-init.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/scripts.js')); ?>"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/moment.js/2.9.0/moment-with-locales.js"></script>
<script src="//cdn.rawgit.com/Eonasdan/bootstrap-datetimepicker/e8bddc60e73c1ec2475f827be36e1957af72e2ea/src/js/bootstrap-datetimepicker.js"></script>

<?php echo $__env->yieldContent('scripts'); ?>
<script>
    $('#event-modal').modal('show')
</script>
<!-- scripit init-->
</body>

</html>
<?php /**PATH C:\phpdir\htdocs\mlmproject\resources\views/layouts/superadmin.blade.php ENDPATH**/ ?>