<?php $__env->startSection('content'); ?>
    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
                <section id="main-content">
                    <div class="row">
                        <div class="col-lg-12" style="margin-top: 7px;">
                            <div class="card alert">
                                <div class="card-header"
                                     style="background: #1DE9B6 !important;border: none;border-radius: 0;">
                                    <h4 style="color: #fff !important;">Withdraw Request From Users</h4>
                                    <div class="card-header-right-icon" style="color: #fff;font-weight: bold;">
                                    </div>
                                </div>
                                <div class="card-body">
                                    <table class="table table-bordered">
                                        <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>
                                                Account
                                            </th>
                                            <th>
                                                Amount (Ksh)
                                            </th>
                                            <th>
                                                Fee(Ksh)
                                            </th>
                                            <th>
                                                Action
                                            </th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $withdraws; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $withdraw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($withdraw->User->name); ?></td>
                                                <td><?php echo e($withdraw->User->email); ?></td>
                                                <td><?php echo e($withdraw->account); ?></td>
                                                <td><?php echo e($withdraw->amount); ?></td>
                                                <td><?php echo e($withdraw->fees); ?></td>
                                                <td>
                                                    <?php if($withdraw->status): ?>
                                                        <a href="<?php echo e(route('admin.withdraw-paid',$withdraw->id)); ?>"
                                                           class="btn btn-sm btn-info">Paid</a>
                                                    <?php else: ?>
                                                        <a href="<?php echo e(route('admin.withdraw-paid',$withdraw->id)); ?>"
                                                           class="btn btn-sm btn-danger">Unpaid</a>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                        </tbody>
                                    </table>
                                    <?php echo e($withdraws->links()); ?>


                                </div>

                            </div>
                            <!-- /# card -->
                        </div>
                        <!-- /# column -->
                    </div>
                </section>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.superadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\phpdir\htdocs\mlmproject\resources\views/superadmin/withdraw-request.blade.php ENDPATH**/ ?>